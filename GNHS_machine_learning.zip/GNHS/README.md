# metabolic_syndrome
The aim of the project is to predict the probability of the individual obtaning metabolic syndrome in the following 10 years.  

Definition of metabolic syndrome:
Metabolic syndrome was defined as meeting three of the five following criteria:
- waist > 90 cm (male) or waist > 85 cm (female), 
- FBG(GLU) ≥ 6.1 mmol/L (110 mg/dl) or previously diagnosed with diabetes mellitus,
- TG ≥ 1.7 mmol/L (150 mg/dl), 
- HDL < 1.04 mmol/L (40 mg/dl)，
- SBP/DBP>=130/85 mmHg or previously diagnosed with high blood pressure.

Assumptions:
 - The prediction will assume the individual does not change their lifestyle siginificantly.

## label redefining
Based on the 5 criteria, we propose to redefine the label thus a better prediction will be made.
The initial prediction of whether a particular inidividual will posses metabolic sydrome will be broken down to 5 sub-labels.
