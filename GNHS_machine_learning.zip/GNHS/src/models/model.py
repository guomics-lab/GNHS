from pathlib import Path
from typing import Dict, List, Optional

import joblib
import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.svm import SVC
from sklearn_genetic import GASearchCV
from sklearn_genetic.callbacks import ConsecutiveStopping, ProgressBar
from sklearn_genetic.space import Continuous, Integer, Categorical
from xgboost import XGBClassifier


def _fit_model(X_train: pd.DataFrame, y_train: pd.DataFrame, config: Dict):
    """
    fit model
    :param y_train: label file
    :param X_train: training dataset
    :param config: config file
    :return:
    """
    if config["classifier"].lower() == "xgb":
        params = {"max_depth": Integer(3, 10),
                  "n_estimators": Integer(100, 1000),
                  "min_child_weight": Continuous(1.0, 2.0),
                  "eta": Continuous(0.01, 0.3),
                  "subsample": Continuous(0.5, 1.0),
                  "colsample_bytree": Continuous(0.5, 1.0),
                  "scale_pos_weight": Continuous(0.5, 2.0),
                  "gamma": Continuous(0, 1.0)
                  }
        clf = XGBClassifier(use_label_encoder=False, eval_metric="mlogloss", random_state=config["seed"])

    elif config["classifier"].lower() == "lr":
        params = {"C": Continuous(0.1, 10)}
        clf = LogisticRegression(random_state=config["seed"])

    elif config["classifier"].lower() == "rf":
        params = {"n_estimators": Integer(100, 1000),
                  "max_depth": Integer(3, 10),
                  "ccp_alpha": Continuous(0, 1)
                  }
        clf = RandomForestClassifier(random_state=config["seed"])

    elif config["classifier"].lower() == "adaboost":
        params = {"n_estimators": Integer(100, 1000),
                  "learning_rate": Continuous(0.001, 1)
                  }
        clf = AdaBoostClassifier(random_state=config["seed"])

    elif config["classifier"].lower() == "svm":
        params = {"C": Continuous(0, 2),
                  "kernel": Categorical(['linear', 'poly', 'rbf', 'sigmoid']),
                  }
        clf = SVC(probability=True, random_state=config["seed"])

    elif config["classifier"].lower() == "lgbm":
        params = {"max_depth": Integer(1, 3),
                  "n_estimators": Integer(100, 1000),
                  "num_leaves": Integer(2, 6),
                  "learning_rate": Continuous(0.01, 0.3),
                  "subsample": Continuous(0.5, 1.0),
                  "colsample_bytree": Continuous(0.5, 1.0),
                  "scale_pos_weight": Continuous(0.5, 2.0),
                  "reg_alpha": Continuous(0, 1.0),
                  "reg_lambda": Continuous(0, 1.0),
                  "min_split_gain": Continuous(0, 1.0),
                  "min_child_weight": Continuous(15.0, 30.0),
                  }
        clf = LGBMClassifier(random_state=config["seed"])

    else:
        raise Exception("Classifier is currently not supported")

    cv = StratifiedKFold(n_splits=config["fold_number"], shuffle=True, random_state=config["seed"])

    print("=" * 20, f"{config['fold_number']}-folds cross validation results with GA-search", "=" * 20)

    stopping_callback = ConsecutiveStopping(generations=3, metric='fitness')
    progress_callback = ProgressBar()
    callbacks = [progress_callback, stopping_callback]

    clf = GASearchCV(estimator=clf,
                     cv=cv,
                     scoring="roc_auc",
                     population_size=8,
                     generations=20,
                     elitism=True,
                     tournament_size=5,
                     crossover_probability=0.8,
                     mutation_probability=0.1,
                     param_grid=params,
                     criteria="max",
                     algorithm="eaMuPlusLambda",
                     n_jobs=4,
                     verbose=True,
                     keep_top_k=5,
                     )

    clf.fit(X_train, y_train, callbacks=callbacks)

    print("Best models parameters:\n", clf.best_params_)
    print("Top 5 models parameters:\n", clf.hof)

    return clf


class EnsembleModel:
    """
    ensemble models that may use sub-labels or the main label with multiple models
    """

    def __init__(self, config: Dict) -> None:
        """
        when initialize the instance, parameter and features will be saved into
        two separated lists(i.e. estimator_list and feature_list)
        :param config: configuration file
        """
        # load models from the parent directories
        parent_dir = Path(config["folder_path"]).resolve() / "results/"

        self.feature_list = list()
        self.estimator_list = list()
        self.sub_label_list = list()
        self.combined_feature = list()
        self.sub_label = config["sub_labels"]
        self.medicine_usage = config["med_usage_condition"]

        for model in config["model_list"]:
            # save sub_label names
            self.sub_label_list.append(model.split("/")[0].split("_")[-1])
            # load features
            with open(parent_dir / f"{model}/params/best_features.csv", "r") as f:
                features = f.readline().strip().split(",")
            print(features)
            self.feature_list.append(features)

            # load models
            with open(parent_dir / f"{model}/params/best_model.pkl", "rb") as f:
                clf = joblib.load(f)
            self.estimator_list.append(clf)

    def get_unique_features(self) -> List:
        """
        :return: unique features from all models
        """
        self.combined_feature = list(set([feature for sublist in self.feature_list for feature in sublist]))
        return self.combined_feature

    def get_feature_list(self) -> List[List]:
        """
        :return: return feature for each sub model
        """
        return self.feature_list

    def predict_proba(self, data: pd.DataFrame, med_dataset: Optional[pd.DataFrame] = None) -> np.ndarray:
        """
        make predictions on the data with probability
        :param data: data used for prediction
        :param med_dataset: dataset for the medicine condition
        :return:
            probabilities of being each class
        """
        predictions = np.zeros((data.shape[0], 2))
        for estimator, features, sub_label in zip(self.estimator_list, self.feature_list, self.sub_label_list):
            data_f = data[features].copy()
            current_prediction = pd.DataFrame(estimator.predict_proba(data_f), index=data.index, columns=["0", "1"])

            if self.medicine_usage:
                # make prediction
                if "sbpdbp" in sub_label:
                    # check the usage of HYPER_med and calibrate the prediction
                    current_prediction = current_prediction.merge(med_dataset["hyper_med"],
                                                                  how="left",
                                                                  left_index=True,
                                                                  right_index=True)
                    current_prediction.loc[current_prediction["hyper_med"] == 0, "0"] = 0
                    current_prediction.loc[current_prediction["hyper_med"] == 1, "1"] = 1
                    current_prediction.drop(columns=["hyper_med"], inplace=True)

                elif "fbg" in sub_label:
                    # check the usage of DM_med and calibrate the prediction
                    current_prediction = current_prediction.merge(med_dataset["DM_med"],
                                                                  how="left",
                                                                  left_index=True,
                                                                  right_index=True)
                    current_prediction.loc[current_prediction["DM_med"] == 0, "0"] = 0
                    current_prediction.loc[current_prediction["DM_med"] == 1, "1"] = 1
                    current_prediction.drop(columns=["DM_med"], inplace=True)

            predictions += current_prediction.values

        return np.array(predictions / len(self.estimator_list))

    def predict(self, data: pd.DataFrame) -> np.ndarray:
        """
        make predictions
        :param data: data used for prediction
        :return:
            predictions (0/1)
        """
        return self.predict_proba(data)[:, 1] > 0.5

    def __repr__(self):
        return f"ensemble model with features of {self.combined_feature}"
