import csv
import pickle
import warnings
from pathlib import Path
from typing import Optional, Dict, Tuple, List, Union

import joblib
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from sklearn.metrics import classification_report, roc_curve, auc
from sklearn.model_selection import train_test_split
from sklearn_genetic import GASearchCV

from src.models.feature_selection import protein_preselection, clinic_preselection, features_select_and_transform
from src.models.model import _fit_model, EnsembleModel
from src.utils.utils import sampling_data, feature_label_split, output_sen_spe_pair, plot_roc_curve, \
    predict_with_threshold, plot_confusion_matrix, plot_probabilities, plot_shapley_values


class Pipeline:
    def __init__(self, config: Dict = None, directory_dict: Dict = None) -> None:
        """
        initialize pipeline
        :param config: the configuration file that captures the requirements for preprocesses
        """

        self.norm = None
        self.config = config
        self.seed = config["seed"]
        self.pretrained = config["pretrained"]
        self.impute = config["impute"]
        self.impute_method = config["impute_method"]
        self.sampling = config["sampling"]
        self.sampling_method = config["sampling_method"]
        self.sampling_threshold = config["sampling_threshold"]
        self.feature_selection_methods = config["feature_selection_methods"]
        self.feature_selection_wrapper_model = config["selector"]
        self.feature_number_limit = config["feature_limit"]
        self.protein_selection_methods = config["protein_selection_methods"]
        self.clinic_selection_methods = config["clinic_selection_methods"]
        self.protein_list = None
        self.clinic_list = None
        self.model_list = config["model_list"]
        self.shapley = config["shapley"]

        if self.pretrained:
            self.load_model(directory_dict=directory_dict)
        else:
            self.feature_list = None
            self.clf = None

    def process_data(self,
                     baseline_data: pd.DataFrame,
                     perspective_data: Optional[pd.DataFrame] = None,
                     test_size: float = None) \
            -> Tuple[pd.DataFrame, pd.DataFrame,
                     pd.DataFrame, pd.DataFrame,
                     Optional[pd.DataFrame], Optional[pd.DataFrame]]:
        """
        perform preprocess to the datasets
        :param baseline_data: baseline dataset
        :param perspective_data: perspective dataset (phase 4)
        :param test_size: the size of test dataset
        :return:
                processed datasets
        """

        if test_size is None:
            test_size = 0.2

        X_baseline, y_baseline = feature_label_split(baseline_data)

        if perspective_data is not None:
            X_perspective, y_perspective = feature_label_split(perspective_data)
        else:
            X_perspective, y_perspective = None, None

        if self.impute:
            assert self.impute_method in ["zero"], "currently not support"
            if self.impute_method == "zero":
                print("Preform imputation")
                X_baseline = X_baseline.fillna(0)
                if X_perspective is not None:
                    X_perspective = X_perspective.fillna(0)
            else:
                raise NotImplemented

        # here we want data split to be the same thus set random state to 0
        X_train_baseline, X_test_baseline, y_train_baseline, y_test_baseline = \
            train_test_split(X_baseline, y_baseline, test_size=test_size, random_state=self.config["seed"])

        print("====================Label Distribution====================")
        print(y_train_baseline.value_counts())
        print(y_test_baseline.value_counts())

        if not self.pretrained:

            if self.sampling:
                print("Preform sampling if proportion of minority class is less than 20%")
                if self.sampling_threshold is None:
                    self.sampling_threshold = 0.2

                if y_train_baseline.value_counts().min() / y_train_baseline.count() < self.sampling_threshold:
                    X_train_baseline, y_train_baseline = sampling_data(X_train_baseline,
                                                                       y_train_baseline,
                                                                       method=self.sampling_method,
                                                                       undersampling_ratio=self.config[
                                                                           "undersampling_rate"],
                                                                       oversampling_ratio=self.config[
                                                                           "oversampling_rate"],
                                                                       seed=self.config["seed"])

            if self.protein_selection_methods:
                print("=" * 30)
                print(f"Start to perform protein selection")
                for method in self.protein_selection_methods:
                    print(f"Performing {method}")
                    X_train_baseline, X_test_baseline, self.protein_list = protein_preselection(method,
                                                                                                X_train_baseline,
                                                                                                y_train_baseline,
                                                                                                X_test_baseline,
                                                                                                y_test_baseline,
                                                                                                self.config)
            if self.clinic_selection_methods:
                print("=" * 30)
                print(f"Start to perform clinic measure selection")
                for method in self.clinic_selection_methods:
                    print(f"Performing {method}")
                    X_train_baseline, X_test_baseline, self.clinic_list = clinic_preselection(method,
                                                                                              X_train_baseline,
                                                                                              y_train_baseline,
                                                                                              X_test_baseline,
                                                                                              y_test_baseline,
                                                                                              self.config)

            for method in self.feature_selection_methods:
                if method != "other":
                    print(f"Performing {method}")
                    X_train_baseline, X_test_baseline, self.feature_list = \
                        features_select_and_transform(method,
                                                      X_train_baseline,
                                                      y_train_baseline,
                                                      X_test_baseline,
                                                      y_test_baseline,
                                                      self.config)
                else:
                    warnings.warn("Feature selection has been skipped")
                    if not self.feature_list:
                        self.feature_list = X_train_baseline.columns
            print(self.feature_list)
        else:
            X_train_baseline = X_train_baseline[self.feature_list]
            X_test_baseline = X_test_baseline[self.feature_list]

        if perspective_data is not None:
            X_perspective = X_perspective[self.feature_list]

        # if preprocess has been done once, retrieve the data directly
        return X_train_baseline, y_train_baseline, X_test_baseline, y_test_baseline, X_perspective, y_perspective

    def fit(self, X_train_baseline: pd.DataFrame, y_train_baseline: pd.DataFrame) -> GASearchCV:
        """train the model"""
        self.clf = _fit_model(X_train_baseline, y_train_baseline, self.config)
        return self.clf

    def save_model(self, directory_dict: Dict) -> None:
        """save trained model to pkl"""
        joblib.dump(self.clf.best_estimator_, directory_dict['best_model'])

        with open(directory_dict['best_param'], "wb") as f:
            pickle.dump(self.clf.best_params_, f)

        with open(directory_dict['top_5_params'], "w") as csvfile:
            writer = csv.writer(csvfile)
            for i, params in self.clf.hof.items():
                writer.writerow([i, params])

        with open(directory_dict['best_features'], "w") as csv_file:
            writer = csv.writer(csv_file)
            writer.writerow(self.feature_list)

    def load_model(self, directory_dict: Dict):
        """load trained model"""
        if self.model_list is not None:
            self.clf = EnsembleModel(self.config)
            self.feature_list = self.clf.get_unique_features()
        else:
            print("+"*100)
            print(directory_dict['best_model'])
            print("+" * 100)
            with open(directory_dict['best_model'], "rb") as f:
                self.clf = joblib.load(f)

            with open(directory_dict['best_features'], "r") as f:
                self.feature_list = f.readline().strip().split(",")

    def get_features(self) -> List:
        """return features"""
        return self.feature_list

    def get_classifier(self) -> Union[GASearchCV, EnsembleModel]:
        """return classifier"""
        return self.clf

    def get_prediction_with_threshold(self,
                                      X: Union[pd.DataFrame, np.ndarray],
                                      threshold=0.5) \
            -> Union[pd.DataFrame, np.ndarray]:
        """get predictions(class)"""
        if not self.clf:
            raise Exception("model not trained")

        return predict_with_threshold(self.clf, X, threshold)

    def get_prediction_proba(self, X: Union[pd.DataFrame, np.ndarray]) -> Union[pd.DataFrame, np.ndarray]:
        """get prediction probabilities"""
        if not self.clf:
            raise Exception("model not trained")
        return self.clf.predict_proba(X)

    @staticmethod
    def generate_prediction_report(y_true: Union[pd.DataFrame, np.ndarray],
                                   y_prob: Union[pd.DataFrame, np.ndarray],
                                   y_hat: Union[pd.DataFrame, np.ndarray]) -> Tuple[np.ndarray, np.ndarray]:
        """
        generate prediction report
        :param y_true: true label
        :param y_prob: probabilities
        :param y_hat: predicted label
        :return:
                fpr, tpr
        """
        print(classification_report(y_true, y_hat))
        fpr, tpr, _ = roc_curve(y_true, y_prob[:, 1], pos_label=1)
        print("roc-auc:", auc(fpr, tpr))
        print(f"specificity at 0.9 sensitivity: {output_sen_spe_pair(fpr, tpr, 0.9)}")
        print(f"specificity at 0.95 sensitivity: {output_sen_spe_pair(fpr, tpr, 0.95)}")

        return fpr, tpr

    @staticmethod
    def generate_plots(y_true: Union[pd.DataFrame, np.ndarray],
                       y_prob: Union[pd.DataFrame, np.ndarray],
                       y_pred: Union[pd.DataFrame, np.ndarray],
                       directory_dict: Dict,
                       config: Dict,
                       dataset_type: str = "baseline_test") -> None:
        """
        make plots
        :param y_true: true label
        :param y_prob: predicted probabilities
        :param y_pred: predicted label with selected threshold
        :param directory_dict: directories for saving plots
        :param config: configuration file
        :param dataset_type: type of dataset (e.g. baseline_test,  perspective)
        :return:
                None
        """
        # probability plot
        _, ax = plt.subplots(figsize=(20, 20))
        plot_probabilities(y_true=y_true, y_prob=y_prob[:, 1], dataset=dataset_type, threshold=config["threshold"], ax=ax)
        plt.savefig(directory_dict['probability'] / f"{dataset_type}_probability_result.pdf", bbox_inches="tight")

        # roc plot
        _, ax = plt.subplots(figsize=(20, 20))
        plot_roc_curve(y_true=y_true, y_proba=y_prob, dataset=dataset_type, ax=ax)
        plt.savefig(directory_dict['roc'] / f"{dataset_type}_roc_curve.pdf", bbox_inches="tight")

        # confusion matrix plot
        _, ax = plt.subplots(figsize=(20, 20))
        plot_confusion_matrix(y_true=y_true, y_pred=y_pred, dataset=dataset_type, ax=ax)
        plt.savefig(directory_dict['confusion_matrix'] / f"{dataset_type}_confusion_matrix.pdf", bbox_inches="tight")

    def generate_shapley_plot(self,
                              X: pd.DataFrame,
                              directory_dict: Dict,
                              dataset_type: str = "baseline_test") -> None:
        """
        make plot based on shapley values
        :param X: feature matrix
        :param directory_dict: directories for saving plots
        :param dataset_type:  type of dataset (e.g. baseline_test,  perspective)
        :return:
                None
        """
        print(self.clf)
        print(X)
        # shapley plot
        if self.shapley:
            _, ax = plt.subplots(figsize=(20, 20))
            if self.model_list is not None:
                plot_shapley_values(model=self.clf.predict,
                                    X_data=X,
                                    name=dataset_type,
                                    config=self.config,
                                    directory_dict=directory_dict)
            else:
                plot_shapley_values(model=self.clf,
                                    X_data=X,
                                    name=dataset_type,
                                    config=self.config,
                                    directory_dict=directory_dict)

    @staticmethod
    def save_results(label: str,
                     seed: int,
                     auc_cv: float,
                     auc_baseline: float,
                     precision_baseline: float,
                     recall_baseline: float,
                     auc_perspective: float = None,
                     precision_perspective: float = None,
                     recall_perspective: float = None,
                     file: Path = Path(r"results//metric_results_met.csv")) -> None:
        """
        this function writes the results into a csv file
        :param file: file to save results
        :param label: which label the models is trying to predict
        :param seed: which seed is used
        :param auc_cv: cross validation auc
        :param auc_baseline: area under the curve for training data
        :param precision_baseline: TP / (TP + FP) for training data
        :param recall_baseline: TP / (TP +　FN) for training data
        :param auc_perspective: area under the curve for perspective data
        :param precision_perspective: TP / (TP + FP) for perspective data
        :param recall_perspective: TP / (TP +　FN) for perspective data
        :return:
        """
        print(f"{label} results with seed of {seed} will be saved into {file}")
        with open(file, "a", newline="", encoding="utf-8") as csvfile:
            writer = csv.writer(csvfile)
            if auc_perspective:
                writer.writerow(
                    [label,
                     seed,
                     auc_cv,
                     auc_baseline,
                     precision_baseline,
                     recall_baseline,
                     auc_perspective,
                     precision_perspective,
                     recall_perspective])
            else:
                writer.writerow([label,
                                 seed,
                                 auc_cv,
                                 auc_baseline,
                                 precision_baseline,
                                 recall_baseline])

    def __repr__(self) -> str:
        return f"Pipeline(impute: {self.impute}, norm: {self.norm}, sampling: {self.sampling})"

    def __str__(self) -> str:
        return f"This is pipeline involves: " \
               f"z-score normalization: {self.norm}" \
               f"imputation ({self.impute_method if self.impute else 'na'}): {self.impute}" \
               f"sampling ({self.sampling_method if self.sampling else 'na'}): {self.sampling}" \
               f"feature_selection_methods of {self.feature_selection_methods}"
