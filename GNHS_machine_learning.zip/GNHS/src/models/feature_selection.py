from collections import Counter
from typing import Dict, List, Tuple

import lightgbm
import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier
from scipy.stats import ttest_ind, mannwhitneyu
from shaphypetune import BoostBoruta, BoostRFE
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.feature_selection import SelectFromModel, SelectKBest, mutual_info_classif, f_classif, RFE
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score
from sklearn.svm import SVC
from xgboost import XGBClassifier


def distribution_deviation(training_dataset: pd.DataFrame,
                           test_dataset: pd.DataFrame,
                           exclude_list=None,
                           threshold: float = 0.01,
                           method: str = "mannwhitneyu") \
        -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    This function compares the training dataset and test dataset (e.g. t-test)
    to ensure the non-significance of feature distribution change
    This function would assume training dataset has the same column as test dataset
    :param training_dataset: the training feature matrix
    :param test_dataset: the test feature matrix (perspective)
    :param exclude_list: the feature that does not need to be included (e.g. clinic data)
    :param threshold: the threshold for the test
    :param method: statistic test used (default: mannwhiteneyu)
    :return:
        dataframe without significance of distribution change
    """

    assert (training_dataset.columns == test_dataset.columns).all(), \
        "training dataset has different columns than test dataset"

    if exclude_list is None:
        exclude_list = ["age", "BMI", "DBP", "Glu", "HDL", "LDL", "SBP", "sex", "TG", "TC", "wc", "dyslipi_med",
                        "DM_med", "hyper_med", "label"]
    feature_list = set(training_dataset.columns) - set(exclude_list)

    print(f"{exclude_list} will not be included in this test")
    print(f"{len(feature_list)} features will be included in this feature selection process...")
    features = []
    for feature in feature_list:
        if method == "mannwhitneyu":
            p_value = mannwhitneyu(training_dataset[feature].dropna(), test_dataset[feature].dropna()).pvalue
        elif method == "ttest":
            p_value = ttest_ind(training_dataset[feature].dropna(), test_dataset[feature].dropna()).pvalue
        else:
            raise Exception("method not supported.")

        if p_value > threshold:
            features.append(feature)
    print(f"{len(features)} features left")
    columns = features + list(set(exclude_list).intersection(training_dataset.columns))

    return training_dataset[columns], test_dataset[columns]


def protein_preselection(method: str,
                         X_train: pd.DataFrame,
                         y_train: pd.DataFrame,
                         X_test: pd.DataFrame,
                         y_test: pd.DataFrame,
                         config: Dict,
                         exclude_list=None
                         ) -> Tuple[pd.DataFrame, pd.DataFrame, List]:
    """This function does a preselection of the protein features,
    it does follows:
    1. remove all non-protein features
    2. fit tree-based features (e.g. random forest, xgboost, lightGBM
    3. only select top-X as candidate proteins
    4. recombine the selected proteins with clinic data
    5. output new dataframe
    :param method: method used for feature selection
    :param X_train: Input dataframe with a mixture of clinic data and protein data (training)
    :param y_train: label (training)
    :param X_test: Input dataframe with a mixture of clinic data and protein data (test)
    :param y_test: label (test)
    :param config: configuration file
    :param exclude_list: list of clinic features

    :return:
        dataframe of preselected proteins and clinic data"""

    if exclude_list is None:
        exclude_list = ["age", "BMI", "DBP", "Glu", "HDL", "LDL", "SBP", "sex", "TG", "wc", "TC"]

    # exclude clinic data
    X_train_prot = X_train.loc[:, ~X_train.columns.isin(exclude_list)]
    X_test_prot = X_test.loc[:, ~X_test.columns.isin(exclude_list)]
    print(f"Original protein count: {X_train_prot.shape[1]}")
    _, _, protein_list = features_select_and_transform(method, X_train_prot, y_train, X_test_prot, y_test, config)
    print(f"Selected protein count: {len(protein_list)}")
    print(f"Selected proteins:\n{protein_list}")
    feature_list = protein_list + list(set(exclude_list).intersection(X_train.columns))
    return X_train[feature_list], X_test[feature_list], protein_list


def clinic_preselection(method: str,
                        X_train: pd.DataFrame,
                        y_train: pd.DataFrame,
                        X_test: pd.DataFrame,
                        y_test: pd.DataFrame,
                        config: Dict,
                        include_list=None
                        ) -> Tuple[pd.DataFrame, pd.DataFrame, List]:
    """This function does a preselection of the protein features,
    it does follows:
    1. remove all non-protein features
    2. fit tree-based features (e.g. random forest, xgboost, lightGBM
    3. only select top-X as candidate proteins
    4. recombine the selected proteins with clinic data
    5. output new dataframe
   :param method: method used for feature selection
    :param X_train: Input dataframe with a mixture of clinic data and protein data (training)
    :param y_train: label (training)
    :param X_test: Input dataframe with a mixture of clinic data and protein data (test)
    :param y_test: label (test)
    :param config: configuration file
    :param include_list: list of clinic features

    :return:
        dataframe of preselected proteins and clinic data"""
    np.random.seed(config["seed"])

    if include_list is None:
        include_list = ["age", "BMI", "DBP", "Glu", "HDL", "LDL", "SBP", "sex", "TG", "wc", "TC"]
    protein_list = list(set(X_train.columns) - set(include_list))
    # exclude clinic data
    X_train_clinic = X_train.loc[:, X_train.columns.isin(include_list)]
    X_test_clinic = X_test.loc[:, X_test.columns.isin(include_list)]
    print(f"Original clinic count: {X_train_clinic.shape[1]}")
    _, _, clinic_list = features_select_and_transform(method, X_train_clinic, y_train, X_test_clinic, y_test, config)
    print(f"Selected clinic count: {len(clinic_list)}")
    print(f"Selected clinic:\n{clinic_list}")
    feature_list = clinic_list + protein_list

    return X_train[feature_list], X_test[feature_list], clinic_list


def t_test_feature_selection(df_X: pd.DataFrame, df_y: pd.DataFrame, threshold: float = 0.05, label: str = "label") \
        -> Tuple[pd.DataFrame, List]:
    """
    this function will perform a t-test feature selection on one dataset
    :param df_X: feature matrix for feature selection
    :param df_y: label file
    :param threshold: selection threshold (p-value)
    :param label: label column name
    :return:
        dataset with selected features and the feature list
    """
    t = []
    for feature in df_X.columns:
        if feature != label:
            p_value = ttest_ind(df_X.loc[df_y == 0, feature],
                                df_X.loc[df_y == 1, feature]).pvalue
            if p_value <= threshold:
                t.append(feature)
    selected = t.copy()
    return df_X[t], selected


def backwards_elimination(df_X: pd.DataFrame, df_y: pd.DataFrame, classifier: str = "xgb", cv: int = 5,
                          max_feature: int = 30, score_metric: str = "auc", seed: int = 0) -> Tuple[pd.DataFrame, List]:
    """
    apply backwards elimination for feature selection
    :param seed: random seed
    :param max_feature: maximum number of features selected
    :param classifier: classifier used for backwards elimination
    :param df_X: feature matrix
    :param df_y: label matrix
    :param cv: number of folds
    :param score_metric: metrics used for scoring

    :return:
        (selected features dataframe, feature list)
    """
    assert classifier.lower() in ["xgb", "rf", "svm", "adaboost", "lgbm"], "models not supported"
    print("=" * 20, "start to backwards eliminate features", "=" * 20)

    if classifier == "xgb":
        clf = XGBClassifier(eval_metric='mlogloss', use_label_encoder=False, random_state=seed)
    elif classifier == "rf":
        clf = RandomForestClassifier(random_state=seed)
    elif classifier == "svm":
        clf = SVC(kernel="linear", C=1.0, random_state=seed)
    elif classifier == "adaboost":
        clf = AdaBoostClassifier()
    elif classifier == "lgbm":
        clf = LGBMClassifier(random_state=seed)
    else:
        raise Exception("Classifier is not supported")

    # initialization
    best_features_ = []
    features = df_X.columns.to_numpy()
    df_y = df_y.values
    best_acc_ = 0
    best_auc_ = 0
    best_f1_ = 0
    best_score_ = 0

    while len(features) > 0:
        n_feature = len(features)
        print(f"remaining feature numbers: {n_feature}")

        cur_acc = np.mean(cross_val_score(clf, df_X[features], df_y, cv=cv))
        cur_auc = np.mean(cross_val_score(clf, df_X[features], df_y, scoring="roc_auc", cv=cv))
        cur_f1 = np.mean(cross_val_score(clf, df_X[features], df_y, scoring="f1_macro", cv=cv))
        cur_score = np.mean(cross_val_score(clf, df_X[features], df_y, scoring=score_metric, cv=cv))

        print(f"current cv acc: {cur_acc:0.3f}, current best acc: {best_acc_:0.3f}")
        print(f"current cv auc: {cur_auc:0.3f}, current best auc: {best_auc_:0.3f}")
        print(f"current cv f1_macro: {cur_f1:0.3f}, current best f1_macro: {best_f1_:0.3f}")
        print(f"current cv score: {cur_score:0.3f}, current best score: {best_score_:0.3f}")

        if n_feature <= max_feature and best_score_ <= cur_score:
            best_acc_ = cur_acc
            best_auc_ = cur_auc
            best_f1_ = cur_f1
            best_score_ = cur_score
            best_features_ = features

        clf.fit(df_X[features], df_y)
        threshold = np.sort(clf.feature_importances_)[0] + 1e-5
        selector = SelectFromModel(clf, threshold=threshold, prefit=True)
        features = features[selector.get_support()]

    print(f"Best {cv}-fold score: {best_score_:0.3f}")
    print(len(best_features_))

    return df_X[best_features_], best_features_


def features_select_and_transform(method: str,
                                  X_train: pd.DataFrame,
                                  y_train: pd.DataFrame,
                                  X_test: pd.DataFrame,
                                  y_test: pd.DataFrame,
                                  config: Dict,
                                  ) \
        -> Tuple[pd.DataFrame, pd.DataFrame, List]:
    """
    this function is used to select features based on set method,
    it will transform the test data obtained from train/test split,
    if validation data is provided, it will transform it as well.
    :param method: method used for feature selection
    :param X_train: training data
    :param y_train: training label
    :param X_test: test data
    :param y_test: test label
    :param config: configuration file
    :return:
        (X_train_transformed, X_test_transformed, Optional(X_validation_transformed), Feature_list)
    """

    # currently, only include 5 feature selection methods, will add more later
    feature_selection_methods = ["lasso", "mutual_info", "anova", "backwards", "rfe", "t_test", "shap_boruta",
                                 "shap_rfe"]
    method = method.lower().strip()
    assert method in feature_selection_methods, "invalid feature selection method"

    # initialize feature list
    feature_list = []

    if method == "lasso":
        threshold = config["lasso_selector_threshold"]
        assert (1.0 >= threshold > 0.0), "invalid lasso selection threshold"

        epochs = config["lasso_epochs"]
        assert epochs > 0, "invalid epoch number"

        # initialize feature list
        feature_list = []
        feature_list_temp = []

        for i in range(epochs):
            np.random.seed(config["seed"])
            selector = SelectFromModel(
                estimator=LogisticRegression(penalty='l1', C=config["lasso_c_value"], solver='liblinear',
                                             random_state=i).fit(X_train,
                                                                 y_train),
                prefit=True)
            current_features = X_train.columns[selector.get_support()].to_list()
            feature_list_temp += current_features
            print(f"{len(current_features)} features has been selected at current round.")
        for k, v in Counter(feature_list_temp).items():
            if v > epochs * threshold:
                # if more than threshold % of times the feature presents, we select it as a candidate
                feature_list.append(k)

        X_train = X_train[feature_list]
        X_test = X_test[feature_list]

        print("=" * 20, "after lasso feature selection", "=" * 20)
        print(f"Number of features been selected {len(feature_list)}")

    elif method == "mutual_info":
        selector = SelectKBest(mutual_info_classif, k=config["feature_limit"]).fit(X_train, y_train)
        feature_list = X_train.columns[selector.get_support()]

        X_train = selector.transform(X_train)
        X_test = selector.transform(X_test)

        print("=" * 20, "after mutual_info feature selection", "=" * 20)
        print(f"Number of features been selected {len(feature_list)}")

    elif method == "anova":
        selector = SelectKBest(f_classif, k=config["feature_limit"]).fit(X_train, y_train)
        feature_list = X_train.columns[selector.get_support()]

        X_train = selector.transform(X_train)
        X_test = selector.transform(X_test)

        print("=" * 20, "after anova feature selection", "=" * 20)
        print(f"Number of features been selected {len(feature_list)}")

    elif method == "shap_boruta":
        if config["selector"] == "lgbm":
            model = BoostBoruta(LGBMClassifier(random_state=config["seed"]), max_iter=200, perc=95,
                                importance_type="feature_importances", sampling_seed=config["seed"])
            model.fit(X_train, y_train, eval_set=[(X_test, y_test)], callbacks=[lightgbm.early_stopping(3)])
        elif config["selector"] == "xgb":
            model = BoostBoruta(XGBClassifier(random_state=config["seed"]), max_iter=200, perc=95,
                                importance_type="feature_importances", sampling_seed=config["seed"])
            model.fit(X_train, y_train, eval_set=[(X_test, y_test)], early_stopping_rounds=3)
        else:
            raise Exception("method currently not supported")
        try:
            X_train = model.transform(X_train)
            X_test = model.transform(X_test)
            feature_list = X_train.columns.to_list()
        except TypeError("No feature selected"):
            feature_list = []

        print("=" * 20, "after Shap_Boruta feature selection", "=" * 20)
        print(f"Number of features been selected {len(feature_list)}")

    elif method == "shap_rfe":
        if config["selector"] == "lgbm":
            model = BoostRFE(LGBMClassifier(random_state=config["seed"]), min_features_to_select=1, step=1,
                             importance_type="shap_importances", sampling_seed=config["seed"])
        elif config["selector"] == "xgb":
            model = BoostRFE(XGBClassifier(random_state=config["seed"]), min_features_to_select=1, step=1,
                             importance_type="shap_importances", sampling_seed=config["seed"])
        else:
            raise Exception("method currently not supported")
        np.random.seed(config["seed"])
        model.fit(X_train, y_train, eval_set=[(X_test, y_test)], early_stopping_rounds=3)

        X_train = model.transform(X_train)
        X_test = model.transform(X_test)
        feature_list = X_train.columns.to_list()

        print("=" * 20, "after Shap_rfe feature selection", "=" * 20)
        print(f"Number of features been selected {model.support_.sum()}")

    elif method == "backwards":
        X_train, feature_list = \
            backwards_elimination(X_train, y_train, config["selector"], cv=config["fold_number"],
                                  max_feature=config["feature_limit"], score_metric="roc_auc")
        X_test = X_test[feature_list]

        print("=" * 20, "after RFE feature selection", "=" * 20)
        print(f"Number of features been selected {len(feature_list)}")

    elif method == "rfe":
        selector = RFE(XGBClassifier(), n_features_to_select=config["feature_limit"], step=10)
        selector = selector.fit(X_train, y_train)
        feature_list = X_train.columns[selector.get_support()]

        X_train = X_train[feature_list]
        X_test = X_test[feature_list]

        print("=" * 20, "after RFE feature selection", "=" * 20)
        print(f"Number of features been selected {len(feature_list)}")

    elif method == "t_test":
        X_train, select_features = t_test_feature_selection(X_train, y_train,
                                                            threshold=0.05)
        X_test = X_test[select_features]
        print("=" * 20, "size of dataset after t-test selection", "=" * 20)
        print(f"X_train dimension: {X_train.shape}, y_train: {y_train.shape}")

    return X_train, X_test, feature_list
