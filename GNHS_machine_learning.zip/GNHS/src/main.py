import os
import random

import matplotlib as mpl
import numpy as np
from sklearn.metrics import precision_score, recall_score, auc

from src.models.pipeline import Pipeline
from src.utils.utils import read_ini, directory_setup, load_data, output_incorrect_preds

if __name__ == "__main__":

    # setup directory
    os.chdir("../src")
    config = read_ini('config.ini')
    directory_dict = directory_setup(config)

    np.random.seed(config["seed"])
    random.seed(config["seed"])
    mpl.rcParams['pdf.fonttype'] = 42

    # load_data
    df_baseline, df_perspective, feature_list, med_usage = load_data(directory_dict)

    # initialize pipeline with current config setup
    pipeline = Pipeline(config, directory_dict)

    X_train_baseline, y_train_baseline, X_test_baseline, y_test_baseline, X_perspective, y_perspective = \
        pipeline.process_data(df_baseline, df_perspective, test_size=0.2)
    print(X_train_baseline.head(5))
    if not config["pretrained"]:
        # train single model
        clf = pipeline.fit(X_train_baseline, y_train_baseline)
        # save model
        pipeline.save_model(directory_dict)
    else:
        # load model (e.g. single model or ensemble model)
        pipeline.load_model(directory_dict)
        # retrieve model
        clf = pipeline.get_classifier()

    # get baseline predictions
    y_proba_test_baseline = pipeline.get_prediction_proba(X=X_test_baseline)
    y_hat_test_baseline = pipeline.get_prediction_with_threshold(X=X_test_baseline,
                                                                 threshold=config["threshold"])

    fpr_test_baseline, tpr_test_baseline = Pipeline.generate_prediction_report(y_true=y_test_baseline,
                                                                               y_prob=y_proba_test_baseline,
                                                                               y_hat=y_hat_test_baseline)

    Pipeline.generate_plots(y_true=y_test_baseline,
                            y_prob=y_proba_test_baseline,
                            y_pred=y_hat_test_baseline,
                            directory_dict=directory_dict,
                            config=config,
                            dataset_type="baseline_test")

    pipeline.generate_shapley_plot(X=X_test_baseline,
                                   directory_dict=directory_dict,
                                   dataset_type="baseline_test")

    # generate shapley value for training data
    pipeline.generate_shapley_plot(X=X_train_baseline,
                                   directory_dict=directory_dict,
                                   dataset_type="baseline_train")

    if config['perspective_dataset']:
        y_proba_perspective = pipeline.get_prediction_proba(X=X_perspective)
        y_hat_perspective = pipeline.get_prediction_with_threshold(X=X_perspective,
                                                                   threshold=config["threshold"])

        fpr_perspective, tpr_perspective = pipeline.generate_prediction_report(y_true=y_perspective,
                                                                               y_prob=y_proba_perspective,
                                                                               y_hat=y_hat_perspective)

        Pipeline.generate_plots(y_true=y_perspective,
                                y_prob=y_proba_perspective,
                                y_pred=y_hat_perspective,
                                directory_dict=directory_dict,
                                config=config,
                                dataset_type="perspective")

        pipeline.generate_shapley_plot(X=X_perspective,
                                       directory_dict=directory_dict,
                                       dataset_type="perspective")

        Pipeline.save_results(label=config["parameter_output"].split("/")[2],
                              seed=config["seed"],
                              auc_cv=clf.history["fitness"][-1] if config["pretrained"] is False else None,
                              auc_baseline=auc(fpr_test_baseline, tpr_test_baseline),
                              precision_baseline=precision_score(y_test_baseline, y_hat_test_baseline),
                              recall_baseline=recall_score(y_test_baseline, y_hat_test_baseline),
                              auc_perspective=auc(fpr_perspective, tpr_perspective),
                              precision_perspective=precision_score(y_perspective, y_hat_perspective),
                              recall_perspective=recall_score(y_perspective, y_hat_perspective),
                              file=directory_dict["result_file"])
    else:

        Pipeline.save_results(label=config["parameter_output"].split("/")[2],
                              seed=config["seed"],
                              auc_cv=clf.history["fitness"][-1] if config["pretrained"] is False else None,
                              auc_baseline=auc(fpr_test_baseline, tpr_test_baseline),
                              precision_baseline=precision_score(y_test_baseline, y_hat_test_baseline),
                              recall_baseline=recall_score(y_test_baseline, y_hat_test_baseline),
                              file=directory_dict["result_file"])

    # output incorrect predictions
    print(output_incorrect_preds(y_test_baseline,
                                 pipeline.get_prediction_with_threshold(X_test_baseline,
                                                                        threshold=config["threshold"]
                                                                        )
                                 )
          )

    print(output_incorrect_preds(y_perspective,
                                 pipeline.get_prediction_with_threshold(X_perspective,
                                                                        threshold=config["threshold"]
                                                                        )
                                 )
          )
