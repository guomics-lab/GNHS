import configparser
import csv
import os
from pathlib import Path
from typing import Tuple, List, Dict, Optional

import imblearn
import matplotlib.pylab as plt
import numpy as np
import pandas as pd
import seaborn as sns
import shap
from sklearn.metrics import confusion_matrix, auc, roc_curve


def sub_label_generator(df_dataset: pd.DataFrame, df_label: pd.DataFrame, label: str) -> pd.DataFrame:
    """used for generate dataset with sub labels 5 criteria
    this function is used for data preprocessing, can be imported into jupyter notebook
    input args:
        df_dataset: input dataset which contains features
        df_label: label information
        label: label column name
    """

    df = df_dataset.merge(df_label[label], how="left", right_index=True, left_index=True)
    df = df.loc[df[label].isin([0, 1]), df.columns != "label"]
    df = df.rename(columns={label: "label"})

    # exclude fbg and sbdbp cases if the individual is taking medicine
    if "sbpdbp" in label:
        df = df.loc[~df["hyper_med"] == 1, :]
    elif "fbg" in label:
        df = df.loc[~df["DM_med"].isin([1, 2, 3, 4]), :]
    elif "hdl" in label or "ldl" in label or "tg" in label or "cg" in label:
        df = df.loc[~df["dyslipi_med"].isin([1, 2, 3, 4]), :]
    df = df.loc[:, ~df.columns.isin(["DM_med", "hyper_med", "dyslipi_med"])]
    print(df.columns)
    print(f"{label} label distribution:\n{df['label'].value_counts()}")

    return df


def read_ini(file_path):
    """
    load ini configuration file
    """
    config = configparser.ConfigParser()
    config.read(file_path)
    configurations = {}
    for section in config.sections():
        for key in config[section]:
            if config[section][key].lower() == "true":
                value: bool = True
            elif config[section][key].lower() == "false":
                value: bool = False
            elif key.lower() in ["fold_number", "feature_limit", "seed", "lasso_epochs"]:
                value: int = int(config[section][key])
            elif key.lower() in ["feature_selection_methods", "model_list", "protein_selection_methods",
                                 "clinic_selection_methods"]:
                print(key, config[section][key])
                if config[section][key].strip() != "":
                    value: List = config[section][key].split(",")
                else:
                    value: None = None
            elif key.lower() in ["lasso_c_value", "threshold", "train_test_split_ratio", "sampling_threshold",
                                 "oversampling_ratio", "undersampling_ratio", "lasso_selector_threshold"]:
                if config[section][key].strip() != "":
                    value: float = float(config[section][key])
                else:
                    value: None = None
            else:
                value: str = config[section][key]
            configurations[key] = value

    # Calculate Shapely values only for pretrained models
    if configurations["pretrained"]:
        configurations["feature_selection_method"] = "other"

    return configurations


def directory_setup(config: Dict) -> Dict[str, Path]:
    """
    set up directory
    :param config: the configuration file
    :return:
        dictionary with following keys:
        baseline_dataset,
        perspective_dataset(optional),
        best_model,
        best_param,
        top_5_params,
        best_features,
        roc,
        confusion_matrix
    """
    directory_dict = {}
    folder = Path(config["folder_path"]).resolve()

    # set up input data directory
    directory_dict['baseline_dataset'] = folder / config['baseline_dataset']
    if config['perspective_dataset']:
        directory_dict['perspective_dataset'] = folder / config['perspective_dataset']

    if config['preselected_features']:
        directory_dict['preselected_features'] = folder / config['preselected_features']
    if config['med_usage_condition']:
        directory_dict['med_usage_condition'] = folder / config['med_usage_condition']

    print(f"\nData sources used:\n"
          f"Training dataset: {directory_dict['baseline_dataset']}\n"
          f"Perspective dataset: {directory_dict.get('perspective_dataset', 'not loaded')}\n"
          f"Preselected features: {directory_dict.get('preselected_features', 'not loaded')}\n"
          f"Medicine usage condition : {directory_dict.get('med_usage_condition', 'not loaded')}")

    # set up directory for storing models parameters
    if not os.path.exists(folder / f"{config['parameter_output']}"):
        print("folder does not exist, creating...")
        os.makedirs(folder / f"{config['parameter_output']}")
    directory_dict['best_model'] = folder / f"{config['parameter_output']}/best_model.pkl"
    directory_dict['best_param'] = folder / f"{config['parameter_output']}/best_param.pkl"
    directory_dict['top_5_params'] = folder / f"{config['parameter_output']}/top5_params.csv"
    directory_dict['best_features'] = folder / f"{config['parameter_output']}/best_features.csv"
    directory_dict['norm_scaler'] = folder / f"{config['parameter_output']}/norm_scaler.pkl"

    print(f"\nModel information will be stored at:\n"
          f"Best models: {directory_dict['best_model']}\n"
          f"Best param: {directory_dict['best_param']}\n"
          f"Top 5 params: {directory_dict['top_5_params']}\n"
          f"Best features: {directory_dict['best_features']}\n"
          f"Normalization scaler: {directory_dict['norm_scaler']}")

    # set up directory for storing models output (plots)
    if not os.path.exists(folder / f"{config['plot_output']}"):
        os.mkdir(folder / f"{config['plot_output']}")
    directory_dict['roc'] = folder / f"{config['plot_output']}"
    directory_dict['confusion_matrix'] = folder / f"{config['plot_output']}"
    directory_dict['shapley_summary'] = folder / f"{config['plot_output']}"
    directory_dict['shapley_interaction'] = folder / f"{config['plot_output']}"
    directory_dict['probability'] = folder / f"{config['plot_output']}"
    directory_dict['result_file'] = folder / f"{config['result_file']}"

    print(f"\nModel output will be stored at:\n"
          f"ROC: {directory_dict['roc']}\n"
          f"Confusion matrix: {directory_dict['confusion_matrix']}\n"
          f"Shapely summary: {directory_dict['shapley_summary']}\n"
          f"Shapely interaction: {directory_dict['shapley_interaction']}\n"
          f"Probability: {directory_dict['probability']}")

    return directory_dict


def load_data(directory_dict: Dict) \
        -> Tuple[pd.DataFrame, Optional[pd.DataFrame], Optional[List], Optional[pd.DataFrame]]:
    """
    load training data,
    also load validation data and pre-selected features if any
    :param directory_dict: configuration file contains the information of directories
    :return:
        (train_data, perspective_dataset, pre-selected features)
    """

    print("=" * 20, "Original size of the input dataset", "=" * 20)
    df_baseline = pd.read_csv(directory_dict['baseline_dataset'], index_col=0)
    print(f"Baseline dataset dimension: {df_baseline.shape}")
    df_perspective = None
    if directory_dict.get('perspective_dataset', ''):
        df_perspective = pd.read_csv(directory_dict['perspective_dataset'], index_col=0)
        print(f"Perspective dataset dimension: {df_perspective.shape}")

    preselected_features = None
    if directory_dict.get('preselected_features', ''):
        preselected_features = pd.read_csv(directory_dict['preselected_features']).columns.to_list()
        preselected_features.append("label")
        # preselected_features = set(preselected_features).intersection(df_input.columns)
        df_baseline = df_baseline[preselected_features]
        preselected_features.remove("label")
        print(f"Preselected features: {preselected_features}")

    med_usage_condition = None
    if directory_dict.get('med_usage_condition', ''):
        med_usage_condition = pd.read_csv(directory_dict['med_usage_condition'], index_col=0)

    return df_baseline, df_perspective, preselected_features, med_usage_condition


def feature_label_split(df: pd.DataFrame, label="label") -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    this function is for splitting features and labels
    :param df: dataset contains between feature and label
    :param label: label column name
    :return:
            (df_feature, df_label)
    """
    return df.loc[:, df.columns != label], df[label]


def combine_dataset(df_sample_1: pd.DataFrame, df_sample_2: pd.DataFrame, label: str = "label") \
        -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Combine two sample datasets with labels, label will be stored in a separate dataframe
    need to make sure the two datasets have the same column name
    :param df_sample_1: dataset 1 with label
    :param df_sample_2: dataset 2 with label
    :param label: label column name
    :return:
        (mets X, mets y)
    """
    df_combined = pd.concat([df_sample_1, df_sample_2], axis=0)
    df_combined_X = df_combined.loc[:, df_combined.columns != label]
    df_combined_y = df_combined.label

    return df_combined_X, df_combined_y


def predict_with_threshold(classifier, data_X: pd.DataFrame, threshold: float = 0.5) -> np.ndarray:
    """
    this function is for prediction with a different threshold
    :param classifier: trained classifier
    :param data_X: dataset
    :param threshold: probability > threshold will be assigned with 1
    :return:
        prediction results
    """

    return (classifier.predict_proba(data_X)[:, 1] > threshold).astype(int)


def plot_roc_curve(y_true: pd.DataFrame, y_proba: np.ndarray, dataset: str, ax):
    """
    this function plots the roc curve for different mode
    :param y_proba: predicted probability
    :param ax: ax used to plot
    :param dataset: {train, test, valid} for display only
    :param y_true: true label
    :return:
            None
    """
    fpr, tpr, _ = roc_curve(y_true=y_true, y_score=y_proba[:, 1], pos_label=1)
    roc_auc = auc(fpr, tpr)

    ax.plot(fpr, tpr, label=f"ROC curve  of {dataset} (area = {roc_auc:0.3f})")
    ax.tick_params(axis='both', which='major', labelsize=16)
    plt.legend(loc="best", prop={'size': 16})
    plt.title('ROC Curve', size=40)
    plt.plot([0, 1], [0, 1], color='black', linestyle=':')
    plt.xlim([0, 1])
    plt.ylim([0, 1])
    plt.xlabel('False Positive Rate', size=25)
    plt.ylabel('True Positive Rate', size=25)
    ax.grid(False)
    sns.despine()


def output_sen_spe_pair(fpr: np.ndarray, tpr: np.ndarray, sen: float = 0.9):
    """
    This function takes fpr, tpr and sensitivity and return the corresponding specificity
    :param fpr: false positive rate
    :param tpr: true positive rate
    :param sen: sensitivity
    :return:
        specificity
    """
    idx = np.where(tpr == min(tpr, key=lambda x: abs(x - sen)))
    return 1 - fpr[idx[0][0]]


def plot_probabilities(y_true: pd.DataFrame,
                       y_prob: np.ndarray,
                       dataset: str,
                       threshold: float,
                       ax: plt.Axes):
    """
    this function is for plotting probabilities
    :param threshold: threshold
    :param y_true: true label
    :param y_prob: probability of being positive label
    :param dataset: {train, test, valid} for display only
    :param ax: ax used to plot
    :return: None
    """
    print("start to plot probabilities....")
    y_axis = range(len(y_prob))
    # this is used for annotation
    samples = y_true.index.to_list()
    sns.scatterplot(x=y_prob, y=y_axis, s=100, hue=y_true, ax=ax)
    for i in y_axis:
        plt.text(x=y_prob[i], y=y_axis[i], s=samples[i], horizontalalignment='left', size='medium', color='black',
                 weight='semibold')
    plt.plot([threshold, threshold], [0, len(y_prob) + 1], color='black', linestyle=':')
    ax.title.set_text(f"Probability plot of {dataset}")
    print("finish plotting probabilities....")


def plot_confusion_matrix(y_true: pd.DataFrame, y_pred: np.ndarray, dataset: str, ax: plt.Axes):
    """
    this function is for plotting confusion matrix
    :param y_true: true label
    :param y_pred: predicted label
    :param dataset: {train, test, valid} for display only
    :param ax: ax used to plot
    :return: None
    """
    print("start to plot confusion matrix....")
    sns.set(font_scale=1.4)
    cm = confusion_matrix(y_true=y_true, y_pred=y_pred)
    df_cm = pd.DataFrame(data=cm, columns=np.unique(y_true), index=np.unique(y_true))
    df_cm.index.name = 'True'
    df_cm.columns.name = 'Predicted'
    g = sns.heatmap(data=df_cm, cmap="Blues", annot=True, annot_kws={"size": 24}, fmt="d", ax=ax)
    ax.set_title(f"Confusion Matrix of {dataset}", fontsize=40)
    g.set_xticklabels(g.get_xmajorticklabels(), fontsize=20)
    g.set_yticklabels(g.get_ymajorticklabels(), fontsize=20)
    ax.set_xlabel('Predicted', size=25)
    ax.set_ylabel('True', size=25)
    print("finish plotting confusion matrix....")


def plot_shapley_values(model, X_data: pd.DataFrame, name: str, config: Dict, directory_dict: Dict):
    """
    this function does plot for shapley values
    :param directory_dict: directory for storing
    :param config: for loading the directory to save figures
    :param name: name of dataset
    :param model: the trained models
    :param X_data: the features
    :return:
    """
    print("start to plot shapley values....")
    if config["model_list"] is None:
        model_type = config["classifier"]
    else:
        model_type = "ensemble_model"
    if model_type.lower() in ["xgb", "lgbm", "adaboost"]:
        explainer = shap.TreeExplainer(model=model, data=X_data, model_output="probability")
    else:
        explainer = shap.Explainer(model, X_data)
    if model_type.lower() in ["xgb", "adaboost", "lgbm"]:
        shap_values = explainer(X_data)
    else:
        shap_values = explainer(X_data)
    # age = ["< 50" if shap_values[i, "age"].data < 50 else "50 - 65" if shap_values[i, "age"].data < 65 else "> 65"
    # for i in range(shap_values.shape[0])]

    # shap.plots.bar(shap_values.cohorts(age).abs.mean(0), show=False)
    shap.summary_plot(shap_values=shap_values, features=X_data, show=False)
    # plt.title(f"Shapely summary of {name}")
    plt.savefig(directory_dict['shapley_summary'] / f"{name}_shapley_summary.pdf", bbox_inches="tight")

    # if model_type.lower() in ["dt", "rf", "xgb"]:
    #     shap_interaction_values = explainer.shap_interaction_values(X_data)
    #     shap.summary_plot(shap_values=shap_interaction_values, features=X_data, show=False)
    #     plt.title(f"Shapely interaction of {name}")
    #     plt.savefig(directory_dict['shapley_interaction'] / f"{name}_shapley_interaction.pdf", bbox_inches="tight")

    # save absolute feature importance into a csv file for other plot
    shap_sum = np.abs(shap_values.values).mean(axis=0)
    df_importance = pd.DataFrame([X_data.columns.tolist(), shap_sum.tolist()]).T
    df_importance.columns = ["feature", "shap_importance"]
    df_importance = df_importance.sort_values("shap_importance", ascending=False)
    df_importance.to_csv(directory_dict['shapley_summary'] / f"{name}_shap_feature_importance.csv", index=False)
    print("finish plotting shapley values....")


def output_incorrect_preds(y_label: pd.DataFrame, y_pred: np.ndarray) -> List:
    """
    this function is used to output incorrect predicted instances
    :param y_label: true label
    :param y_pred:  predicted label
    :return:
        dataframe of incorrect data
    """
    return y_label[y_label != y_pred].index.to_list()


def sampling_data(df_X: pd.DataFrame,
                  df_y: pd.DataFrame,
                  undersampling_ratio: float = None,
                  oversampling_ratio: float = None,
                  method: str = "mets",
                  seed: int = 0) \
        -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    used to sample data
    :param df_y: label
    :param df_X: dataset
    :param undersampling_ratio: the ratio used in undersampling ranged from 0 to 1,where 1 means undersample
                                the majority labels to be equal amount to the minority labels
    :param oversampling_ratio: the ratio used in no_sampling ranged from 0 to 1, where 1 means no_sampling
                                the minority labels to be equal amount to the majority labels
    :param method: undersampling (will use random undersampling)
                   no_sampling (will use SMOTE)
                   (default) mets (undersampling + no_sampling)
    :param seed: random seed

    :return:
        sampled dataset
    """
    if undersampling_ratio is None:
        undersampling_ratio = 1

    if oversampling_ratio is None:
        oversampling_ratio = 1

    if method == "mets":
        oversample = imblearn.over_sampling.ADASYN(sampling_strategy=oversampling_ratio, n_neighbors=6,
                                                   random_state=seed)
        undersample = imblearn.under_sampling.ClusterCentroids(sampling_strategy=undersampling_ratio, random_state=seed)
        steps = [('o', oversample), ('u', undersample)]
        pipeline = imblearn.pipeline.Pipeline(steps=steps)
        return pipeline.fit_resample(df_X, df_y)
    elif method == "no_sampling":
        oversample = imblearn.over_sampling.ADASYN(sampling_strategy=oversampling_ratio, random_state=seed)
        return oversample.fit_resample(df_X, df_y)
    elif method == "undersampling":
        undersample = imblearn.under_sampling.RandomUnderSampler(sampling_strategy=undersampling_ratio,
                                                                 random_state=seed)
        return undersample.fit_resample(df_X, df_y)


def calibrator(label: pd.DataFrame, probs: np.ndarray):
    """
    Bayes Minimum Risk
    based on the following paper
    https://www3.nd.edu/~dial/publications/dalpozzolo2015calibrating.pdf

    :param label: the label file
    :param probs: probabilities of being positive
    :return
        calibrated probabilities
    """

    beta = label.sum() / len(label)

    return probs / (probs + (1 - probs) / beta)


def feature_selector(metric: str, clinic_dir: Path, protein_dir: Path, preselected_features_dir: Path) -> None:
    """
    this function is used for selecting the best feature combination (clinic and protein)
     based on the chosen metric
    :param preselected_features_dir: directory that stores preselected features
    :param protein_dir: directory that stores protein related result
    :param clinic_dir: directory that stores clinic related result
    :param metric: the metric used for selecting the best model
    :return:
            list of features used in mets feature model
    """
    clinic_features = pd.read_csv(clinic_dir / "metric_results.csv")
    clinic_seed = clinic_features.sort_values(by=metric, ascending=False).head(1).seed.values[0]
    clinic_selected_features = pd.read_csv(
        clinic_dir / f"seed_{clinic_seed}/params/best_features.csv").columns.to_list()

    protein_features = pd.read_csv(clinic_dir / "metric_results.csv")
    protein_seed = protein_features.sort_values(by=metric, ascending=False).head(1).seed.values[0]
    protein_selected_features = pd.read_csv(
        protein_dir / f"seed_{protein_seed}/params/best_features.csv").columns.to_list()

    combined_selected_features = clinic_selected_features + protein_selected_features
    print(combined_selected_features)

    if not os.path.exists(preselected_features_dir):
        preselected_features_dir.mkdir(parents=True)
    preselected_features_file = preselected_features_dir / "preselected_feature.csv"

    with open(preselected_features_file, "w") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(combined_selected_features)


def result_file_creation(result_dir: Path) -> None:
    """
    create file and corresponding directory for storing results
    :param result_dir: the target directory for storing metric results
    """

    if not os.path.exists(result_dir):
        result_dir.mkdir(parents=True)
    if not os.path.exists(result_dir / "metric_results.csv"):
        with open(result_dir / "metric_results.csv", "w", newline='') as csv_file:
            writer = csv.writer(csv_file)
            writer.writerow(["label",
                             "seed",
                             "auc_cv",
                             "auc_baseline",
                             "precision_baseline",
                             "recall_baseline",
                             "auc_perspective",
                             "precision_perspective",
                             "recall_perspective"])
