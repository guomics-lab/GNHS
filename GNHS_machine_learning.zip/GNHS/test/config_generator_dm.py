import os
from configparser import ConfigParser
from pathlib import Path

from src.utils.utils import feature_selector, result_file_creation

if __name__ == "__main__":

    os.chdir("../src")

    config = ConfigParser()
    config.read("config.ini")

    # the label to predict
    label = "dm"

    # set up preselected feature directory for combined model
    preselected_features = f"data/preselected_features/{label}/preselected_feature.csv"

    ###########################################################
    #                     protein model                       #
    ###########################################################

    dataset_type = "protein"

    # set up some parameters
    impute = "true"
    impute_method = "zero"

    norm = "true"

    sampling = "no_sampling"

    feature_selection_methods = "lasso, shap_boruta"
    feature_limit = "100"
    selector = "lgbm"  # this is for wrapped methods e.g. rfe, boruta
    protein_selection_methods = ""
    clinic_selection_methods = ""

    # LASSO
    lasso_epochs = "10"
    lasso_c_value = "0.25"
    lasso_selector_threshold = "0.95"

    classifier = "lgbm"
    pretrained = "False"

    protein_dir = Path(f"D:/GitHub/GNHS/results/2022/{label}/protein/{impute}/{sampling}").resolve()
    result_file_creation(protein_dir)
    for seed in range(25):

        # set up input files
        baseline_dataset = f"data/transformed_data/2022/{label}/{label}_{dataset_type}_baseline.csv"
        perspective_dataset = f"data/transformed_data/2022/{label}/{label}_{dataset_type}_perspective.csv"
        med_usage_condition = f""

        # set up directory
        parameter_output = \
            f"results/2022/{label}/{dataset_type}/{impute}/{sampling}/seed_{seed}/params/"
        plot_output = \
            f"results/2022/{label}/{dataset_type}/{impute}/{sampling}/seed_{seed}/plots/"
        result_file = f"results/2022/{label}/{dataset_type}/{impute}/{sampling}/metric_results.csv"

        # update pretrain
        config.set("MODEL", "pretrained", pretrained)

        # update directory
        config.set("DIRECTORY", "baseline_dataset", baseline_dataset)
        config.set("DIRECTORY", "perspective_dataset", perspective_dataset)
        config.set("DIRECTORY", "med_usage_condition", med_usage_condition)
        config.set("DIRECTORY", "parameter_output", parameter_output)
        config.set("DIRECTORY", "plot_output", plot_output)
        config.set("DIRECTORY", "result_file", result_file)

        if dataset_type in ["clinic", "protein"]:
            config.set("DIRECTORY", "preselected_features", "")
        else:
            config.set("DIRECTORY", "preselected_features", preselected_features)

        # set sampling
        if sampling != "no_sampling":
            config.set("SAMPLING", "sampling", "True")
            config.set("SAMPLING", "sampling_method", sampling)
        else:
            config.set("SAMPLING", "sampling", "False")

        # set imputation
        config.set("PREPROCESSING", "impute", impute)
        config.set("PREPROCESSING", "impute_method", impute_method)

        # set normalization
        config.set("PREPROCESSING", "norm", norm)

        # set feature selection
        config.set("FEATURE_SELECTION", "feature_selection_methods", feature_selection_methods)
        config.set("FEATURE_SELECTION", "feature_limit", feature_limit)
        config.set("FEATURE_SELECTION", "selector", selector)

        if dataset_type in ["clinic", "protein"]:
            config.set("FEATURE_SELECTION", "protein_selection_methods", "")
            config.set("FEATURE_SELECTION", "clinic_selection_methods", "")
        else:
            config.set("FEATURE_SELECTION", "protein_selection_methods", protein_selection_methods)
            config.set("FEATURE_SELECTION", "clinic_selection_methods", clinic_selection_methods)

        # lasso
        config.set("LASSO", "lasso_epochs", lasso_epochs)
        config.set("LASSO", "lasso_c_value", lasso_c_value)
        config.set("LASSO", "lasso_selector_threshold", lasso_selector_threshold)

        # set classification model
        config.set("MODEL", "classifier", classifier)

        # update random seed
        config.set("SEED", "seed", str(seed))

        # write to file
        with open("config.ini", "w") as configfile:
            config.write(configfile)

        # run script
        os.system("python main.py")

    ###########################################################
    #                     clinic model                        #
    ###########################################################
    dataset_type = "clinic"

    # set up some parameters
    impute = "true"
    impute_method = "zero"

    norm = "true"

    sampling = "no_sampling"

    feature_selection_methods = "backwards"
    feature_limit = "100"
    selector = "lgbm"  # this is for wrapped methods e.g. rfe, boruta
    protein_selection_methods = ""
    clinic_selection_methods = ""

    # LASSO
    lasso_epochs = "10"
    lasso_c_value = "0.2"
    lasso_selector_threshold = "0.95"

    classifier = "lgbm"
    pretrained = "False"

    clinic_dir = Path(f"D:/GitHub/GNHS/results/2022/{label}/{dataset_type}/{impute}/{sampling}").resolve()
    result_file_creation(clinic_dir)

    for seed in range(25):
        # set up input files
        baseline_dataset = f"data/transformed_data/2022/{label}/{label}_{dataset_type}_baseline.csv"
        perspective_dataset = f"data/transformed_data/2022/{label}/{label}_{dataset_type}_perspective.csv"
        med_usage_condition = f""

        # set up directory
        parameter_output = \
            f"results/2022/{label}/{dataset_type}/{impute}/{sampling}/seed_{seed}/params/"
        plot_output = \
            f"results/2022/{label}/{dataset_type}/{impute}/{sampling}/seed_{seed}/plots/"
        result_file = f"results/2022/{label}/{dataset_type}/{impute}/{sampling}/metric_results.csv"

        # update pretrain
        config.set("MODEL", "pretrained", pretrained)

        # update directory
        config.set("DIRECTORY", "baseline_dataset", baseline_dataset)
        config.set("DIRECTORY", "perspective_dataset", perspective_dataset)
        config.set("DIRECTORY", "med_usage_condition", med_usage_condition)
        config.set("DIRECTORY", "parameter_output", parameter_output)
        config.set("DIRECTORY", "plot_output", plot_output)
        config.set("DIRECTORY", "result_file", result_file)

        if dataset_type in ["clinic", "protein"]:
            config.set("DIRECTORY", "preselected_features", "")
        else:
            config.set("DIRECTORY", "preselected_features", preselected_features)

        # set sampling
        if sampling != "no_sampling":
            config.set("SAMPLING", "sampling", "True")
            config.set("SAMPLING", "sampling_method", sampling)
        else:
            config.set("SAMPLING", "sampling", "False")

        # set imputation
        config.set("PREPROCESSING", "impute", impute)
        config.set("PREPROCESSING", "impute_method", impute_method)

        # set normalization
        config.set("PREPROCESSING", "norm", norm)

        # set feature selection
        config.set("FEATURE_SELECTION", "feature_selection_methods", feature_selection_methods)
        config.set("FEATURE_SELECTION", "feature_limit", feature_limit)
        config.set("FEATURE_SELECTION", "selector", selector)

        if dataset_type in ["clinic", "protein"]:
            config.set("FEATURE_SELECTION", "protein_selection_methods", "")
            config.set("FEATURE_SELECTION", "clinic_selection_methods", "")
        else:
            config.set("FEATURE_SELECTION", "protein_selection_methods", protein_selection_methods)
            config.set("FEATURE_SELECTION", "clinic_selection_methods", clinic_selection_methods)

        # lasso
        config.set("LASSO", "lasso_epochs", lasso_epochs)
        config.set("LASSO", "lasso_c_value", lasso_c_value)
        config.set("LASSO", "lasso_selector_threshold", lasso_selector_threshold)

        # set classification model
        config.set("MODEL", "classifier", classifier)

        # update random seed
        config.set("SEED", "seed", str(seed))

        # write to file
        with open("config.ini", "w") as configfile:
            config.write(configfile)

        # run script
        os.system("python main.py")

    ###########################################################
    #                    preselect features                   #
    ###########################################################

    # this section extracts the feature for combined model
    preselected_features_dir = Path(f"D:/GitHub/GNHS/data/preselected_features/{label}").resolve()
    feature_selector(metric="auc_cv",
                     clinic_dir=clinic_dir,
                     protein_dir=protein_dir,
                     preselected_features_dir=preselected_features_dir)

    ###########################################################
    #                     combined model                      #
    ###########################################################

    dataset_type = "combined"

    # set up some parameters
    impute = "true"
    impute_method = "zero"

    norm = "true"

    sampling = "no_sampling"

    feature_selection_methods = "shap_boruta"
    feature_limit = "100"
    selector = "lgbm"  # this is for wrapped methods e.g. rfe, boruta
    protein_selection_methods = ""
    clinic_selection_methods = ""

    # LASSO
    lasso_epochs = "10"
    lasso_c_value = "0.2"
    lasso_selector_threshold = "0.95"

    classifier = "lgbm"
    pretrained = "False"

    combined_dir = Path(f"D:/GitHub/GNHS/results/2022/{label}/{dataset_type}/{impute}/{sampling}").resolve()
    result_file_creation(combined_dir)

    for seed in range(25):

        # set up input files
        baseline_dataset = f"data/transformed_data/2022/{label}/{label}_{dataset_type}_baseline.csv"
        perspective_dataset = f"data/transformed_data/2022/{label}/{label}_{dataset_type}_perspective.csv"
        med_usage_condition = f""

        # set up directory
        parameter_output = \
            f"results/2022/{label}/{dataset_type}/{impute}/{sampling}/seed_{seed}/params/"
        plot_output = \
            f"results/2022/{label}/{dataset_type}/{impute}/{sampling}/seed_{seed}/plots/"
        result_file = f"results/2022/{label}/{dataset_type}/{impute}/{sampling}/metric_results.csv"

        # update pretrain
        config.set("MODEL", "pretrained", pretrained)

        # update directory
        config.set("DIRECTORY", "baseline_dataset", baseline_dataset)
        config.set("DIRECTORY", "perspective_dataset", perspective_dataset)
        config.set("DIRECTORY", "med_usage_condition", med_usage_condition)
        config.set("DIRECTORY", "parameter_output", parameter_output)
        config.set("DIRECTORY", "plot_output", plot_output)
        config.set("DIRECTORY", "result_file", result_file)

        if dataset_type in ["clinic", "protein"]:
            config.set("DIRECTORY", "preselected_features", "")
        else:
            config.set("DIRECTORY", "preselected_features", preselected_features)

        # set sampling
        if sampling != "no_sampling":
            config.set("SAMPLING", "sampling", "True")
            config.set("SAMPLING", "sampling_method", sampling)
        else:
            config.set("SAMPLING", "sampling", "False")

        # set imputation
        config.set("PREPROCESSING", "impute", impute)
        config.set("PREPROCESSING", "impute_method", impute_method)

        # set normalization
        config.set("PREPROCESSING", "norm", norm)

        # set feature selection
        config.set("FEATURE_SELECTION", "feature_selection_methods", feature_selection_methods)
        config.set("FEATURE_SELECTION", "feature_limit", feature_limit)
        config.set("FEATURE_SELECTION", "selector", selector)

        if dataset_type in ["clinic", "protein"]:
            config.set("FEATURE_SELECTION", "protein_selection_methods", "")
            config.set("FEATURE_SELECTION", "clinic_selection_methods", "")
        else:
            config.set("FEATURE_SELECTION", "protein_selection_methods", protein_selection_methods)
            config.set("FEATURE_SELECTION", "clinic_selection_methods", clinic_selection_methods)

        # lasso
        config.set("LASSO", "lasso_epochs", lasso_epochs)
        config.set("LASSO", "lasso_c_value", lasso_c_value)
        config.set("LASSO", "lasso_selector_threshold", lasso_selector_threshold)

        # set classification model
        config.set("MODEL", "classifier", classifier)

        # update random seed
        config.set("SEED", "seed", str(seed))

        # write to file
        with open("config.ini", "w") as configfile:
            config.write(configfile)

        # run script
        os.system("python main.py")
